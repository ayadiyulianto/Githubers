package com.akusuka.githubers

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.google.android.material.appbar.AppBarLayout
import com.google.android.material.snackbar.Snackbar
import kotlinx.android.synthetic.main.activity_detail.*

class DetailActivity : AppCompatActivity(), View.OnClickListener {

    companion object{
        const val EXTRA_USER = "extra_user"
    }

    private lateinit var user: User
    private lateinit var detailViewModel: DetailViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        val intentUser = intent.getParcelableExtra<Users>(EXTRA_USER)
        loadViewModel(intentUser)
        initToolbar()

        val detailPagerAdapter = DetailPagerAdapter(this, supportFragmentManager, intentUser.username)
        view_pager.adapter = detailPagerAdapter
        tabs.setupWithViewPager(view_pager)

        ic_favorite.setOnClickListener(this)
        ic_message.setOnClickListener(this)
    }

    private fun loadViewModel(intentUsers: Users?){
        showLoading(true)
        detailViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).
            get(DetailViewModel::class.java)
        detailViewModel.setUser(intentUsers?.username)
        detailViewModel.getUser().observe(this, Observer { userItem ->
            if (userItem != null) {
                user = userItem
                showUserDetail()
                showLoading(false)
            }
        })
    }

    private fun initToolbar(){
        setSupportActionBar(toolBar)
        val actionBar = supportActionBar
        actionBar?.setDisplayHomeAsUpEnabled(true)

        var isShow = true
        var scrollRange = -1
        appBar.addOnOffsetChangedListener(AppBarLayout.OnOffsetChangedListener { barLayout, verticalOffset ->
            if (scrollRange == -1){
                scrollRange = barLayout?.totalScrollRange!!
            }
            if (scrollRange + verticalOffset == 0){
                cToolbar.title = user.name
                cToolbar.setCollapsedTitleTextColor(Color.WHITE)
                isShow = true
            } else if (isShow){
                cToolbar.title = " "
                isShow = false
            }
        })
    }

    override fun onNavigateUp(): Boolean {
        onBackPressed()
        return super.onNavigateUp()
    }

    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(R.anim.right_in, R.anim.right_out)
    }

    private fun showUserDetail(){
        Glide.with(this)
            .load(user.avatar_url)
            .into(img_avatar)
        tv_name.text = user.name
        tv_username.text = user.username
    }

    override fun onClick(view: View) {
        when(view.id){
            R.id.ic_favorite -> {
                Toast.makeText(this, R.string.favorite, Toast.LENGTH_SHORT).show()
            }
            R.id.ic_message -> {
                Toast.makeText(this, getString(R.string.chat), Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun showLoading(state: Boolean) {
        if(state) {
            progressBar.visibility = View.VISIBLE
        }else {
            progressBar.visibility = View.GONE
        }
    }

}
