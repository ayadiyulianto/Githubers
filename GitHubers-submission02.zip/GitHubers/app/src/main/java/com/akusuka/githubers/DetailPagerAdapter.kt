package com.akusuka.githubers

import android.content.Context
import androidx.annotation.Nullable
import androidx.annotation.StringRes
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter

class DetailPagerAdapter(private val mContext: Context, fm: FragmentManager, private val username: String) :
    FragmentPagerAdapter(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT) {

    @StringRes
    private val TAB_TITLES = intArrayOf(R.string.profile, R.string.following, R.string.followers, R.string.repository)

    override fun getItem(position: Int): Fragment {
        var fragment: Fragment? = null
        when (position) {
            0 -> fragment = ProfileFragment.newInstance(username)
            1 -> fragment = FollowFragment.newInstance(username, FollowFragment.FOLLOWING)
            2 -> fragment = FollowFragment.newInstance(username, FollowFragment.FOLLOWERS)
            3 -> fragment = RepositoryFragment.newInstance(username)
        }
        return fragment as Fragment
    }

    @Nullable
    override fun getPageTitle(position: Int): CharSequence? {
        return mContext.resources.getString(TAB_TITLES[position])
    }

    override fun getCount(): Int {
        return 4
    }
}