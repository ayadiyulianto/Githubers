package com.akusuka.githubers

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Path
import retrofit2.http.Query


interface GitHubService {
    companion object {
        const val PAS = "3f01856e8e370049837937d6c1da6b3ed510cbc4"
        const val TOKEN = "Authorization: token $PAS"
    }

    @Headers(TOKEN)
    @GET("search/users")
    fun getUsers(
        @Query("q") query: String
    ): Call<CallbackUsers?>?

    @Headers(TOKEN)
    @GET("users/{username}")
    fun getUser(
        @Path("username") username: String?
    ): Call<User?>?

    @Headers(TOKEN)
    @GET("users/{username}/followers")
    fun getFollowers(
        @Path("username") username: String?
    ): Call<ArrayList<Users>?>?

    @Headers(TOKEN)
    @GET("users/{username}/following")
    fun getFollowing(
        @Path("username") username: String?
    ): Call<ArrayList<Users>?>?

    @Headers(TOKEN)
    @GET("users/{username}/repos")
    fun getRepository(
        @Path("username") username: String?
    ): Call<ArrayList<Repository>?>?
}