package com.akusuka.githubers

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainViewModel : ViewModel() {

    private val listUsers = MutableLiveData<ArrayList<Users>>()
    private val gitHubService: GitHubService = RestAdapter.gitHubService

    fun setUsers(query: String) {
        val callbackCall: Call<CallbackUsers?>? = gitHubService.getUsers(query)
        callbackCall?.enqueue(object : Callback<CallbackUsers?> {
            override fun onResponse(call: Call<CallbackUsers?>?, response: Response<CallbackUsers?>) {
                val resp: CallbackUsers? = response.body()
                if (resp != null) {
                    listUsers.postValue(resp.items)
                } else {
                    Log.d("onResponse", "Not Found")
                }
            }
            override fun onFailure(call: Call<CallbackUsers?>, t: Throwable?) {
                Log.d("onFailure", t.toString())
            }
        })
    }

    fun getUsers(): LiveData<ArrayList<Users>> {
        return listUsers
    }

}