package com.akusuka.githubers

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

data class CallbackUsers(
    var total_count: Int = 0,
    var incomplete_results: Boolean = false,
    var items: ArrayList<Users> = arrayListOf()
)

@Parcelize
data class Users (
    @SerializedName("login")
    var username: String = "",
    var avatar_url: String = ""
) : Parcelable

data class User (
    @SerializedName("login")
    var username: String = "",
    var avatar_url: String = "",
    var name: String = "",
    var company: String = "",
    var blog: String = "",
    var location: String = "",
    var email: String = "",
    var bio: String = "",
    var public_repos: Int = 0,
    var followers: Int = 0,
    var following: Int = 0
)

data class Repository(
    var name: String = "",
    var description: String = "",
    var language: String = "",
    var updated_at: String = ""
)