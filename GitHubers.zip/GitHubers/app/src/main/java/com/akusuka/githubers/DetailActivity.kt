package com.akusuka.githubers

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.google.android.material.appbar.AppBarLayout
import kotlinx.android.synthetic.main.activity_detail.*

class DetailActivity : AppCompatActivity(), View.OnClickListener {

    companion object{
        const val EXTRA_USER = "extra_user"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        val user = intent.getParcelableExtra<User>(EXTRA_USER)
        initToolbar(user?.name)
        showUserDetail(user)

        ic_favorite.setOnClickListener(this)
        ic_message.setOnClickListener(this)
    }

    fun initToolbar(title: String?){
        setSupportActionBar(toolBar)
        val actionBar = supportActionBar
        actionBar?.setDisplayHomeAsUpEnabled(true)

        var isShow = true
        var scrollRange = -1
        appBar.addOnOffsetChangedListener(AppBarLayout.OnOffsetChangedListener { barLayout, verticalOffset ->
            if (scrollRange == -1){
                scrollRange = barLayout?.totalScrollRange!!
            }
            if (scrollRange + verticalOffset == 0){
                cToolbar.title = title
                cToolbar.setCollapsedTitleTextColor(Color.WHITE)
                isShow = true
            } else if (isShow){
                cToolbar.title = " "
                isShow = false
            }
        })
    }

    override fun onNavigateUp(): Boolean {
        onBackPressed()
        return super.onNavigateUp()
    }

    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(R.anim.right_in, R.anim.right_out)
    }

    fun showUserDetail(user: User?){
        val drawableId = this.resources.getIdentifier(user?.avatar, "drawable", this.packageName)
        Glide.with(this)
            .load(drawableId)
            .into(img_avatar)
        tv_name.text = user?.name
        tv_username.text = user?.username
        tv_repository.text = user?.repository.toString()
        tv_following.text = user?.following.toString()
        tv_follower.text = user?.follower.toString()
        tv_company.text = user?.company
        tv_location.text = user?.location
    }

    override fun onClick(view: View) {
        when(view.id){
            R.id.ic_favorite -> {
                Toast.makeText(this, "Follow", Toast.LENGTH_SHORT).show()
            }
            R.id.ic_message -> {
                Toast.makeText(this, "Chat", Toast.LENGTH_SHORT).show()
            }
        }
    }

}
