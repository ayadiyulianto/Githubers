package com.akusuka.githubers

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    private var list: ArrayList<User> = arrayListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(R.style.AppTheme)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Init Toolbar
        setSupportActionBar(toolBar)
        val actionBar = supportActionBar
        actionBar?.setDisplayShowTitleEnabled(false)
        actionBar?.setDisplayHomeAsUpEnabled(true)
        toolBar.setNavigationIcon(R.drawable.ic_baseline_menu_24)

        rv_users.setHasFixedSize(true)

        prepare()
        showRecyclerView()
    }

    private fun prepare(){
        val userData = UsersData.userData
        if (userData != null) {
            list.addAll(userData)
            list.sortBy { it.name }
        }
    }

    private fun showRecyclerView(){
        rv_users.layoutManager = LinearLayoutManager(this)
        val listPieceAdapter = ListUserAdapter(list)
        rv_users.adapter = listPieceAdapter

        listPieceAdapter.setOnItemClickCallback(object : ListUserAdapter.OnItemClickCallback{
            override fun onItemClicked(data: User) {
                showSelectedUser(data)
            }
        })
    }

    private fun showSelectedUser(user: User){
        Toast.makeText(this, "Kamu memilih " + user.name, Toast.LENGTH_SHORT).show()
        val intent = Intent(this@MainActivity, DetailActivity::class.java)
        intent.putExtra(DetailActivity.EXTRA_USER, user)
        startActivity(intent)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when(item?.itemId) {
            R.id.menu_my_profile -> {
                Toast.makeText(this, "My Profile", Toast.LENGTH_SHORT).show()
                val intent = Intent(this@MainActivity, DetailActivity::class.java)
                val user: User = UsersData.myData
                intent.putExtra(DetailActivity.EXTRA_USER, user)
                startActivity(intent)
            }
            android.R.id.home -> {
                Toast.makeText(this, "Klik Menu", Toast.LENGTH_SHORT).show()
            }
        }
        return super.onOptionsItemSelected(item)
    }

}
